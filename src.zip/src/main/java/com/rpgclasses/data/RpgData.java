package com.rpgclasses.data;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.math.MathHelper;

public class RpgData {
    public static final String KEY = "rpgclasses";
    /** 0=Força 1=Vitalidade 2=Agilidade 3=Inteligência */
    public static final String[] STAT_NAMES = {"Força", "Vitalidade", "Agilidade", "Inteligência"};
    public static final String[] STAT_HINTS = {"dano/skills físicas", "vida", "velocidade/arco", "skills mágicas/mana"};
    public static final int POINTS_PER_LEVEL = 3;

    public RpgClass rpgClass = RpgClass.NONE;
    public Rank rank = Rank.E;
    public int level = 1;
    public int xp = 0;
    public int points = 0;
    public int[] stats = new int[4];
    public float mana = 50f;
    public SkillSpec[] skills = new SkillSpec[6];

    // Só para sincronização (não salvo)
    public float maxMana = 50f;
    public int[] cdLeft = new int[6];

    public int cap() { return rank.levelCap; }
    public int xpToNext() { return 100 + level * 50; }

    public CompoundNBT toTag() {
        CompoundNBT t = new CompoundNBT();
        t.putInt("class", rpgClass.ordinal());
        t.putInt("rank", rank.ordinal());
        t.putInt("level", level);
        t.putInt("xp", xp);
        t.putInt("points", points);
        t.putIntArray("stats", stats);
        t.putFloat("mana", mana);
        t.putFloat("maxMana", maxMana);
        for (int i = 0; i < 6; i++) if (skills[i] != null) t.putIntArray("sk" + i, skills[i].toArray());
        t.putIntArray("cd", cdLeft);
        return t;
    }

    public static RpgData fromTag(CompoundNBT t) {
        RpgData d = new RpgData();
        d.rpgClass = RpgClass.values()[MathHelper.clamp(t.getInt("class"), 0, RpgClass.values().length - 1)];
        d.rank = Rank.values()[MathHelper.clamp(t.getInt("rank"), 0, Rank.values().length - 1)];
        d.level = Math.max(1, t.getInt("level"));
        d.xp = t.getInt("xp");
        d.points = t.getInt("points");
        int[] s = t.getIntArray("stats");
        for (int i = 0; i < Math.min(4, s.length); i++) d.stats[i] = s[i];
        d.mana = t.contains("mana") ? t.getFloat("mana") : 50f;
        d.maxMana = t.contains("maxMana") ? t.getFloat("maxMana") : 50f;
        for (int i = 0; i < 6; i++) if (t.contains("sk" + i)) d.skills[i] = SkillSpec.fromArray(t.getIntArray("sk" + i));
        int[] cd = t.getIntArray("cd");
        for (int i = 0; i < Math.min(6, cd.length); i++) d.cdLeft[i] = cd[i];
        return d;
    }

    /** Lê do servidor (persistente; copiado na morte via evento Clone). */
    public static RpgData get(PlayerEntity p) {
        CompoundNBT root = p.getPersistentData();
        return root.contains(KEY, 10) ? fromTag(root.getCompound(KEY)) : new RpgData();
    }

    public void save(PlayerEntity p) { p.getPersistentData().put(KEY, toTag()); }

    /** Funciona nos dois lados (o cliente usa o dado sincronizado). */
    public static RpgData of(PlayerEntity p) { return p.level.isClientSide ? ClientData.data : get(p); }
}
