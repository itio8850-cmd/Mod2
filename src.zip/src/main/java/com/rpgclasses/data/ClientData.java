package com.rpgclasses.data;

/** Cópia dos dados do jogador local, sincronizada pelo servidor. */
public class ClientData {
    public static RpgData data = new RpgData();
    public static long ticks = 0;
    public static long[] cdEnd = new long[6];
}
