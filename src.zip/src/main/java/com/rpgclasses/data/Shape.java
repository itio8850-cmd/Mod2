package com.rpgclasses.data;

/** Forma da skill: como ela acerta os alvos. */
public enum Shape {
    PROJECTILE("Projétil", Rank.E, 10, 40, 1.0f),
    MELEE("Golpe em Arco", Rank.E, 8, 30, 1.3f),
    SELF("Pessoal", Rank.E, 6, 60, 0f),
    NOVA("Nova (ao redor)", Rank.D, 18, 80, 0.8f),
    BEAM("Raio Perfurante", Rank.C, 20, 70, 0.9f),
    IMPACT("Impacto em Área", Rank.C, 22, 90, 1.0f);

    public final String display;
    public final Rank minRank;
    public final int mana, cooldown;
    public final float dmgMult;

    Shape(String display, Rank minRank, int mana, int cooldown, float dmgMult) {
        this.display = display;
        this.minRank = minRank;
        this.mana = mana;
        this.cooldown = cooldown;
        this.dmgMult = dmgMult;
    }
}
