package com.rpgclasses.data;

/** Ranks e seus level caps. Edite os valores aqui. */
public enum Rank {
    E(10), D(20), C(30), B(45), A(60), S(100);

    public final int levelCap;

    Rank(int levelCap) { this.levelCap = levelCap; }

    public Rank next() { return ordinal() + 1 < values().length ? values()[ordinal() + 1] : null; }
}
