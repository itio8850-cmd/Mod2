package com.rpgclasses.data;

import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleTypes;

/** Elemento da skill: tipo de dano e efeito. */
public enum Element {
    NONE("Neutro", Rank.E, 0, 0f, false, ParticleTypes.HAPPY_VILLAGER),
    PHYSICAL("Físico", Rank.E, 0, 1.0f, true, ParticleTypes.CRIT),
    FIRE("Fogo", Rank.E, 4, 1.1f, false, ParticleTypes.FLAME),
    ICE("Gelo", Rank.E, 4, 1.0f, false, ParticleTypes.ITEM_SNOWBALL),
    POISON("Veneno", Rank.E, 3, 0.8f, false, ParticleTypes.ITEM_SLIME),
    LIGHTNING("Raio", Rank.D, 6, 1.25f, false, ParticleTypes.ENCHANTED_HIT),
    DARK("Sombrio", Rank.C, 6, 1.1f, false, ParticleTypes.SMOKE),
    HOLY("Sagrado", Rank.C, 6, 1.0f, false, ParticleTypes.END_ROD);

    public final String display;
    public final Rank minRank;
    public final int mana;
    public final float dmgMult;
    /** true = escala com Força; false = escala com Inteligência. */
    public final boolean physical;
    public final IParticleData particle;

    Element(String display, Rank minRank, int mana, float dmgMult, boolean physical, IParticleData particle) {
        this.display = display;
        this.minRank = minRank;
        this.mana = mana;
        this.dmgMult = dmgMult;
        this.physical = physical;
        this.particle = particle;
    }
}
