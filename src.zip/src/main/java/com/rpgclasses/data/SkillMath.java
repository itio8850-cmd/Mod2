package com.rpgclasses.data;

/** Fórmulas compartilhadas (servidor e cliente, para o preview da GUI). */
public class SkillMath {

    public static float damage(RpgClass cls, int level, SkillSpec s, int str, int intel, float skillPower) {
        Element e = s.element();
        if (s.shape() == Shape.SELF || e == Element.NONE) return 0f;
        float scale = e.physical ? str : intel;
        float dmg = (4f + level * 0.25f + scale * 0.6f) * s.shape().dmgMult * e.dmgMult * (1f + skillPower);
        if (s.has(SkillMod.POWER)) dmg *= 1.5f;
        if (s.has(SkillMod.QUICK)) dmg *= 0.85f;
        if (cls == RpgClass.WARRIOR && e.physical) dmg *= 1.2f;
        if (cls == RpgClass.MAGE && !e.physical) dmg *= 1.2f;
        if (cls == RpgClass.ARCHER && (s.shape() == Shape.PROJECTILE || s.shape() == Shape.BEAM)) dmg *= 1.2f;
        return dmg;
    }

    public static int mana(RpgClass cls, SkillSpec s) {
        return Math.max(1, Math.round(s.manaCost() * (cls == RpgClass.MAGE ? 0.8f : 1f)));
    }

    public static int cooldown(RpgClass cls, SkillSpec s) {
        return Math.max(10, Math.round(s.cooldown() * (cls == RpgClass.ROGUE ? 0.85f : 1f)));
    }

    public static float maxMana(RpgClass cls, int level, int intel) {
        float m = 50f + intel * 4f + level * 2f;
        return cls == RpgClass.MAGE ? m * 1.2f : m;
    }

    /** Mana por segundo. */
    public static float regen(int level, int intel) { return 3f + intel * 0.25f + level * 0.1f; }
}
