package com.rpgclasses.data;

/** A classe só dá bônus passivos. Qualquer classe pode usar qualquer skill/equipamento. */
public enum RpgClass {
    NONE("Nenhuma", "", 0, 0, 0),
    WARRIOR("Guerreiro", "Skills físicas +20% dano, mais vida", 0.5, 0.10, 0.0),
    MAGE("Mago", "Skills elementais +20% dano, -20% mana, +20% mana máx.", 0.2, 0.02, 0.0005),
    ARCHER("Arqueiro", "Projétil/Raio +20% dano, mais velocidade", 0.3, 0.05, 0.002),
    ROGUE("Ladino", "Recarga -15%, Executar mais forte", 0.25, 0.08, 0.003);

    public final String displayName;
    public final String description;
    /** Bônus por nível (acima do nível 1). */
    public final double hpPerLevel, dmgPerLevel, speedPerLevel;

    RpgClass(String displayName, String description, double hp, double dmg, double speed) {
        this.displayName = displayName;
        this.description = description;
        this.hpPerLevel = hp;
        this.dmgPerLevel = dmg;
        this.speedPerLevel = speed;
    }
}
