package com.rpgclasses.net;

import com.rpgclasses.data.ClientData;
import com.rpgclasses.data.RpgData;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente */
public class SyncPacket {
    public final CompoundNBT tag;

    public SyncPacket(CompoundNBT tag) { this.tag = tag; }

    public static void encode(SyncPacket m, PacketBuffer b) { b.writeNbt(m.tag); }

    public static SyncPacket decode(PacketBuffer b) { return new SyncPacket(b.readNbt()); }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            RpgData nd = RpgData.fromTag(m.tag);
            ClientData.data = nd;
            for (int i = 0; i < 6; i++) ClientData.cdEnd[i] = ClientData.ticks + nd.cdLeft[i];
        });
        c.setPacketHandled(true);
    }
}
