package com.rpgclasses.net;

import com.rpgclasses.logic.RpgLogic;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Cliente -> Servidor.
 * 0=escolher classe [classe] | 1=gastar ponto [stat] | 2=subir rank
 * 3=usar skill [slot] | 4=salvar skill [slot, forma, elemento, m0, m1, m2] | 5=apagar skill [slot]
 */
public class ActionPacket {
    public final int action;
    public final int[] args;

    public ActionPacket(int action, int[] args) {
        this.action = action;
        this.args = args;
    }

    public static void encode(ActionPacket m, PacketBuffer b) {
        b.writeVarInt(m.action);
        b.writeVarIntArray(m.args);
    }

    public static ActionPacket decode(PacketBuffer b) { return new ActionPacket(b.readVarInt(), b.readVarIntArray()); }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ServerPlayerEntity pl = c.getSender();
            if (pl != null) RpgLogic.handleAction(pl, m.action, m.args);
        });
        c.setPacketHandled(true);
    }
}
