package com.rpgclasses.item;

import com.rpgclasses.data.Rank;
import com.rpgclasses.data.RpgData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Rarity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;

import java.util.List;

public interface RpgGear {
    GearSpec spec();

    default boolean usable(PlayerEntity p) {
        return RpgData.of(p).rank.ordinal() >= spec().rank.ordinal();
    }

    default void deny(PlayerEntity p) {
        if (!p.level.isClientSide) {
            p.displayClientMessage(new StringTextComponent("Requer Rank " + spec().rank.name() + "+")
                    .withStyle(TextFormatting.RED), true);
        }
    }

    static Rarity rarity(Rank r) {
        if (r.ordinal() <= 1) return Rarity.COMMON;
        if (r.ordinal() <= 3) return Rarity.UNCOMMON;
        if (r.ordinal() == 4) return Rarity.RARE;
        return Rarity.EPIC;
    }

    default void addTooltip(List<ITextComponent> tip) {
        GearSpec g = spec();
        tip.add(new StringTextComponent("Rank mínimo: " + g.rank.name()).withStyle(TextFormatting.GRAY));
        String[] n = {"FOR", "VIT", "AGI", "INT"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) if (g.stats[i] != 0) sb.append("+").append(g.stats[i]).append(" ").append(n[i]).append("  ");
        if (sb.length() > 0) tip.add(new StringTextComponent(sb.toString().trim()).withStyle(TextFormatting.GREEN));
        if (g.skillPower > 0) tip.add(new StringTextComponent("+" + Math.round(g.skillPower * 100) + "% poder de skills")
                .withStyle(TextFormatting.AQUA));
        if (g.arrowBonus > 0) tip.add(new StringTextComponent("+" + g.arrowBonus + " dano de flecha")
                .withStyle(TextFormatting.GOLD));
        if (g.hitEffect != null) tip.add(new StringTextComponent("Aplica efeito ao acertar").withStyle(TextFormatting.GOLD));
    }
}
