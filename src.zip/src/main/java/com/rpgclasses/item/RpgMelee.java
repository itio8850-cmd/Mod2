package com.rpgclasses.item;

import com.rpgclasses.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.potion.EffectInstance;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/** Espadas, machados, martelos, adagas, lanças, katanas e cajados. */
public class RpgMelee extends SwordItem implements RpgGear {
    private final GearSpec spec;

    public RpgMelee(IItemTier tier, int dmg, float speed, GearSpec spec) {
        super(tier, dmg, speed, new Item.Properties().tab(ModItems.TAB).rarity(RpgGear.rarity(spec.rank)));
        this.spec = spec;
    }

    @Override public GearSpec spec() { return spec; }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean r = super.hurtEnemy(stack, target, attacker);
        if (spec.hitEffect != null) target.addEffect(new EffectInstance(spec.hitEffect.get(), spec.hitTicks, spec.hitAmp));
        return r;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tip, ITooltipFlag flag) {
        addTooltip(tip);
    }
}
