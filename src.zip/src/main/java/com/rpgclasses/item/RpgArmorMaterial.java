package com.rpgclasses.item;

import com.rpgclasses.RpgClassesMod;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;

import java.util.function.Supplier;

public class RpgArmorMaterial implements IArmorMaterial {
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11}; // botas, calças, peitoral, capacete
    private final String name;
    private final int durMult;
    private final int[] defense; // botas, calças, peitoral, capacete
    private final float toughness, knockback;
    private final Supplier<Ingredient> repair;

    public RpgArmorMaterial(String name, int durMult, int[] defense, float toughness, float knockback,
                            Supplier<Ingredient> repair) {
        this.name = name;
        this.durMult = durMult;
        this.defense = defense;
        this.toughness = toughness;
        this.knockback = knockback;
        this.repair = repair;
    }

    @Override public int getDurabilityForSlot(EquipmentSlotType slot) { return BASE_DURABILITY[slot.getIndex()] * durMult; }
    @Override public int getDefenseForSlot(EquipmentSlotType slot) { return defense[slot.getIndex()]; }
    @Override public int getEnchantmentValue() { return 15; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_IRON; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
    @Override public String getName() { return RpgClassesMod.MODID + ":" + name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockback; }
}
