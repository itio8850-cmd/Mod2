package com.rpgclasses.item;

import com.rpgclasses.data.Rank;
import net.minecraft.potion.Effect;

import java.util.function.Supplier;

/** Dados de um equipamento: rank mínimo, bônus de atributos, poder de skill e efeito ao acertar. */
public class GearSpec {
    public final Rank rank;
    public final int[] stats = new int[4];
    public float skillPower = 0f;
    public Supplier<Effect> hitEffect = null;
    public int hitTicks, hitAmp;
    public double arrowBonus = 0;

    public GearSpec(Rank rank) { this.rank = rank; }

    public GearSpec stats(int str, int vit, int agi, int intel) {
        stats[0] = str; stats[1] = vit; stats[2] = agi; stats[3] = intel;
        return this;
    }

    public GearSpec skill(float p) { this.skillPower = p; return this; }

    public GearSpec hit(Supplier<Effect> e, int ticks, int amp) {
        this.hitEffect = e; this.hitTicks = ticks; this.hitAmp = amp;
        return this;
    }

    public GearSpec arrow(double b) { this.arrowBonus = b; return this; }
}
