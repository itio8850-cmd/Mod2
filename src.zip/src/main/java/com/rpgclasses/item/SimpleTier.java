package com.rpgclasses.item;

import net.minecraft.item.IItemTier;
import net.minecraft.item.crafting.Ingredient;

import java.util.function.Supplier;

public class SimpleTier implements IItemTier {
    private final int uses, ench;
    private final Supplier<Ingredient> repair;

    public SimpleTier(int uses, int ench, Supplier<Ingredient> repair) {
        this.uses = uses;
        this.ench = ench;
        this.repair = repair;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return 6.0F; }
    @Override public float getAttackDamageBonus() { return 0.0F; }
    @Override public int getLevel() { return 2; }
    @Override public int getEnchantmentValue() { return ench; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
