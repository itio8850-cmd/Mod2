package com.rpgclasses.item;

import com.rpgclasses.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class RpgArmor extends ArmorItem implements RpgGear {
    private final GearSpec spec;

    public RpgArmor(IArmorMaterial mat, EquipmentSlotType slot, GearSpec spec) {
        super(mat, slot, new Item.Properties().tab(ModItems.TAB).rarity(RpgGear.rarity(spec.rank)));
        this.spec = spec;
    }

    @Override public GearSpec spec() { return spec; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tip, ITooltipFlag flag) {
        addTooltip(tip);
    }
}
