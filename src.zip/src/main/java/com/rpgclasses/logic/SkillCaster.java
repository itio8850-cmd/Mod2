package com.rpgclasses.logic;

import com.rpgclasses.data.*;
import net.minecraft.entity.CreatureAttribute;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.server.ServerWorld;

import java.util.*;

/** Executa as skills montadas pelo jogador. */
public class SkillCaster {
    private static final Map<UUID, long[]> CD = new HashMap<>();

    public static long[] cdFor(ServerPlayerEntity p) {
        long[] a = CD.get(p.getUUID());
        if (a == null) {
            a = new long[6];
            CD.put(p.getUUID(), a);
        }
        return a;
    }

    public static void forget(UUID id) { CD.remove(id); }

    private static void bar(ServerPlayerEntity p, String s, TextFormatting f) {
        p.displayClientMessage(new StringTextComponent(s).withStyle(f), true);
    }

    public static void cast(ServerPlayerEntity p, int slot) {
        RpgData d = RpgData.get(p);
        if (d.rpgClass == RpgClass.NONE || slot < 0 || slot >= SkillSpec.slots(d.rank)) return;
        SkillSpec s = d.skills[slot];
        if (s == null) {
            bar(p, "Slot vazio (tecla J para criar skills)", TextFormatting.GRAY);
            return;
        }
        long now = p.level.getGameTime();
        long[] cds = cdFor(p);
        if (now < cds[slot]) return;

        GearUtil.Total g = GearUtil.of(p, d.rank);
        int str = d.stats[0] + g.stats[0];
        int intel = d.stats[3] + g.stats[3];
        int cost = SkillMath.mana(d.rpgClass, s);
        if (d.mana < cost) {
            bar(p, "Mana insuficiente (" + cost + ")", TextFormatting.RED);
            return;
        }
        d.mana -= cost;
        cds[slot] = now + SkillMath.cooldown(d.rpgClass, s);

        float dmg = SkillMath.damage(d.rpgClass, d.level, s, str, intel, g.skillPower);
        ServerWorld w = (ServerWorld) p.level;
        Vector3d start = p.getEyePosition(1.0F);
        List<LivingEntity> targets = new ArrayList<>();
        Element el = s.element();

        switch (s.shape()) {
            case PROJECTILE: {
                Vector3d end = rayEnd(p, 25);
                List<LivingEntity> l = alongRay(p, start, end, 0.4);
                if (!l.isEmpty()) {
                    targets.add(l.get(0));
                    end = l.get(0).position().add(0, l.get(0).getBbHeight() / 2, 0);
                }
                trail(w, el, start, end);
                break;
            }
            case BEAM: {
                Vector3d end = rayEnd(p, 20);
                targets.addAll(alongRay(p, start, end, 0.9));
                trail(w, el, start, end);
                break;
            }
            case MELEE: {
                Vector3d look = p.getLookAngle();
                for (LivingEntity en : w.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(3.5, 1.0, 3.5),
                        o -> valid(p, o))) {
                    Vector3d to = en.position().add(0, en.getBbHeight() / 2, 0).subtract(start);
                    if (to.length() <= 4.0 && to.normalize().dot(look) > 0.35) targets.add(en);
                }
                Vector3d f = start.add(look.scale(1.8));
                w.sendParticles(ParticleTypes.SWEEP_ATTACK, f.x, f.y - 0.3, f.z, 1, 0, 0, 0, 0);
                w.sendParticles(el.particle, f.x, f.y - 0.3, f.z, 12, 0.6, 0.3, 0.6, 0.05);
                break;
            }
            case NOVA: {
                for (LivingEntity en : w.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(5.0), o -> valid(p, o))) {
                    if (en.distanceToSqr(p) <= 25.0) targets.add(en);
                }
                for (int i = 0; i < 40; i++) {
                    double ang = i * Math.PI * 2 / 40;
                    w.sendParticles(el.particle, p.getX() + Math.cos(ang) * 5, p.getY() + 0.3, p.getZ() + Math.sin(ang) * 5,
                            1, 0, 0.1, 0, 0.02);
                }
                break;
            }
            case IMPACT: {
                Vector3d at = rayEnd(p, 20);
                for (LivingEntity en : w.getEntitiesOfClass(LivingEntity.class, new AxisAlignedBB(at, at).inflate(4.0), o -> valid(p, o))) {
                    if (en.position().distanceTo(at) <= 4.5) targets.add(en);
                }
                trail(w, el, start, at);
                w.sendParticles(el.particle, at.x, at.y + 0.5, at.z, 50, 1.5, 0.8, 1.5, 0.08);
                break;
            }
            default: // SELF
                w.sendParticles(el.particle, p.getX(), p.getY() + 1, p.getZ(), 15, 0.4, 0.6, 0.4, 0.05);
                break;
        }

        float totalDealt = 0;
        for (LivingEntity t : targets) totalDealt += hit(p, w, t, s, dmg, d.rpgClass);

        // Efeitos no próprio conjurador
        if (s.has(SkillMod.LIFESTEAL) && totalDealt > 0) p.heal(totalDealt * 0.35f);
        if (s.has(SkillMod.HEAL)) p.heal(4f + d.level * 0.15f + intel * 0.2f);
        if (s.has(SkillMod.SHIELD)) p.addEffect(new EffectInstance(Effects.ABSORPTION, 300, 1 + d.level / 25));
        if (s.has(SkillMod.HASTE)) p.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 160, 1));
        if (s.has(SkillMod.FURY)) p.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 160, 1));
        if (s.has(SkillMod.REGEN)) p.addEffect(new EffectInstance(Effects.REGENERATION, 120, 1));
        if (s.has(SkillMod.STEALTH)) p.addEffect(new EffectInstance(Effects.INVISIBILITY, 100, 0));
        if (s.has(SkillMod.DASH)) {
            Vector3d look = p.getLookAngle();
            p.setDeltaMovement(look.x * 1.5, Math.max(0.15, look.y * 0.6), look.z * 1.5);
            p.hurtMarked = true;
            p.fallDistance = 0;
        }

        w.playSound(null, p.getX(), p.getY(), p.getZ(),
                el.physical ? SoundEvents.PLAYER_ATTACK_SWEEP : SoundEvents.ILLUSIONER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 1.0F);
        bar(p, s.name(), TextFormatting.AQUA);
        d.save(p);
        RpgLogic.sync(p, d);
    }

    private static boolean valid(ServerPlayerEntity p, LivingEntity o) {
        if (o == p || !o.isAlive() || o instanceof ArmorStandEntity) return false;
        if (o instanceof TameableEntity && ((TameableEntity) o).isOwnedBy(p)) return false;
        if (o instanceof PlayerEntity && !((ServerWorld) p.level).getServer().isPvpAllowed()) return false;
        return true;
    }

    private static Vector3d rayEnd(ServerPlayerEntity p, double range) {
        Vector3d start = p.getEyePosition(1.0F);
        Vector3d end = start.add(p.getLookAngle().scale(range));
        BlockRayTraceResult br = p.level.clip(new RayTraceContext(start, end,
                RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, p));
        return br.getType() == RayTraceResult.Type.MISS ? end : br.getLocation();
    }

    private static List<LivingEntity> alongRay(ServerPlayerEntity p, Vector3d start, Vector3d end, double width) {
        AxisAlignedBB box = new AxisAlignedBB(start, end).inflate(width + 1.0);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity en : p.level.getEntitiesOfClass(LivingEntity.class, box, o -> valid(p, o))) {
            AxisAlignedBB bb = en.getBoundingBox().inflate(width);
            if (bb.contains(start) || bb.clip(start, end).isPresent()) out.add(en);
        }
        Collections.sort(out, new Comparator<LivingEntity>() {
            @Override
            public int compare(LivingEntity a, LivingEntity b) {
                return Double.compare(a.distanceToSqr(start), b.distanceToSqr(start));
            }
        });
        return out;
    }

    private static void trail(ServerWorld w, Element e, Vector3d a, Vector3d b) {
        Vector3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 0.1) return;
        Vector3d step = dir.normalize().scale(0.7);
        Vector3d pos = a.add(0, -0.25, 0).add(step);
        for (double t = 0; t < len; t += 0.7) {
            w.sendParticles(e.particle, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
            pos = pos.add(step);
        }
    }

    /** Aplica dano + efeitos no alvo. Retorna o dano realmente causado. */
    private static float hit(ServerPlayerEntity p, ServerWorld w, LivingEntity t, SkillSpec s, float dmg, RpgClass cls) {
        Element e = s.element();
        float dealt = 0;
        if (dmg > 0) {
            float amount = dmg;
            if (s.has(SkillMod.EXECUTE) && t.getHealth() < t.getMaxHealth() * 0.3f) amount *= (cls == RpgClass.ROGUE ? 1.7f : 1.5f);
            if (e == Element.HOLY && t.getMobType() == CreatureAttribute.UNDEAD) amount *= 1.8f;
            DamageSource src = e.physical ? DamageSource.playerAttack(p) : DamageSource.indirectMagic(p, p);
            float before = t.getHealth();
            t.hurt(src, amount);
            dealt = Math.max(0f, before - t.getHealth());

            switch (e) {
                case FIRE: t.setSecondsOnFire(5); break;
                case ICE: t.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 80, 1)); break;
                case POISON: t.addEffect(new EffectInstance(Effects.POISON, 100, 0)); break;
                case DARK: t.addEffect(new EffectInstance(Effects.WITHER, 60, 0)); break;
                case LIGHTNING: {
                    for (LivingEntity n : w.getEntitiesOfClass(LivingEntity.class, t.getBoundingBox().inflate(4.0),
                            o -> o != t && valid(p, o))) {
                        n.hurt(DamageSource.indirectMagic(p, p), amount * 0.5f);
                        w.sendParticles(e.particle, n.getX(), n.getY() + 1, n.getZ(), 10, 0.3, 0.5, 0.3, 0.1);
                        break;
                    }
                    break;
                }
                default: break;
            }
        }
        w.sendParticles(e.particle, t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(), 10, 0.3, 0.3, 0.3, 0.05);

        if (s.has(SkillMod.KNOCKBACK)) t.knockback(1.0F, p.getX() - t.getX(), p.getZ() - t.getZ());
        if (s.has(SkillMod.PULL)) {
            Vector3d v = p.position().subtract(t.position());
            v = new Vector3d(v.x, 0, v.z).normalize().scale(1.1);
            t.setDeltaMovement(v.x, 0.25, v.z);
            t.hurtMarked = true;
        }
        if (s.has(SkillMod.STUN)) t.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 40, 6));
        if (s.has(SkillMod.BLIND)) t.addEffect(new EffectInstance(Effects.BLINDNESS, 80, 0));
        if (s.has(SkillMod.LAUNCH)) {
            Vector3d m = t.getDeltaMovement();
            t.setDeltaMovement(m.x, 0.9, m.z);
            t.hurtMarked = true;
        }
        return dealt;
    }
}
