package com.rpgclasses.logic;

import com.rpgclasses.data.Rank;
import com.rpgclasses.data.RpgData;
import com.rpgclasses.item.GearSpec;
import com.rpgclasses.item.RpgGear;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;

/** Soma os bônus de todo o equipamento (mão principal, secundária e armadura). */
public class GearUtil {
    public static class Total {
        public int[] stats = new int[4];
        public float skillPower = 0f;
    }

    public static Total of(PlayerEntity p) { return of(p, RpgData.of(p).rank); }

    public static Total of(PlayerEntity p, Rank rank) {
        Total t = new Total();
        add(t, p.getMainHandItem(), rank, false);
        add(t, p.getOffhandItem(), rank, false);
        add(t, p.getItemBySlot(EquipmentSlotType.HEAD), rank, true);
        add(t, p.getItemBySlot(EquipmentSlotType.CHEST), rank, true);
        add(t, p.getItemBySlot(EquipmentSlotType.LEGS), rank, true);
        add(t, p.getItemBySlot(EquipmentSlotType.FEET), rank, true);
        return t;
    }

    private static void add(Total t, ItemStack st, Rank rank, boolean armorSlot) {
        if (st.isEmpty() || !(st.getItem() instanceof RpgGear)) return;
        boolean isArmor = st.getItem() instanceof ArmorItem;
        if (isArmor != armorSlot) return;
        GearSpec g = ((RpgGear) st.getItem()).spec();
        if (rank.ordinal() < g.rank.ordinal()) return;
        for (int i = 0; i < 4; i++) t.stats[i] += g.stats[i];
        t.skillPower += g.skillPower;
    }
}
