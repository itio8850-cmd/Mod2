package com.rpgclasses.logic;

import com.rpgclasses.ModItems;
import com.rpgclasses.data.*;
import com.rpgclasses.net.ModNetwork;
import com.rpgclasses.net.SyncPacket;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.attributes.ModifiableAttributeInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.Util;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RpgLogic {
    private static final UUID HP_ID = UUID.fromString("5b1c1f10-0001-4a00-9a00-000000000001");
    private static final UUID DMG_ID = UUID.fromString("5b1c1f10-0002-4a00-9a00-000000000002");
    private static final UUID SPD_ID = UUID.fromString("5b1c1f10-0003-4a00-9a00-000000000003");
    private static final UUID ASPD_ID = UUID.fromString("5b1c1f10-0004-4a00-9a00-000000000004");

    public static void msg(ServerPlayerEntity p, String text, TextFormatting fmt) {
        p.sendMessage(new StringTextComponent(text).withStyle(fmt), Util.NIL_UUID);
    }

    public static void handleAction(ServerPlayerEntity p, int action, int[] a) {
        RpgData d = RpgData.get(p);
        if (action == 3) { // usar skill
            if (a.length >= 1) SkillCaster.cast(p, a[0]);
            return;
        }
        switch (action) {
            case 0: // escolher classe
                if (a.length >= 1 && d.rpgClass == RpgClass.NONE && a[0] > 0 && a[0] < RpgClass.values().length) {
                    d.rpgClass = RpgClass.values()[a[0]];
                    giveStarter(p, d);
                }
                break;
            case 1: // gastar ponto
                if (a.length >= 1 && d.points > 0 && a[0] >= 0 && a[0] < 4) {
                    d.stats[a[0]]++;
                    d.points--;
                }
                break;
            case 2: // subir de rank
                Rank next = d.rank.next();
                if (next != null && d.level >= d.cap()) {
                    if (consumeStone(p)) {
                        d.rank = next;
                        msg(p, "Você alcançou o Rank " + next.name() + "! Novo level cap: " + next.levelCap
                                + " | Slots de skill: " + SkillSpec.slots(next), TextFormatting.AQUA);
                    } else {
                        msg(p, "Você precisa de uma Pedra de Ascensão.", TextFormatting.RED);
                    }
                }
                break;
            case 4: // salvar skill
                if (a.length >= 6) saveSkill(p, d, a);
                break;
            case 5: // apagar skill
                if (a.length >= 1 && a[0] >= 0 && a[0] < 6) d.skills[a[0]] = null;
                break;
            default:
                break;
        }
        d.save(p);
        refresh(p, d);
    }

    private static void saveSkill(ServerPlayerEntity p, RpgData d, int[] a) {
        int slot = a[0], shape = a[1], el = a[2];
        if (slot < 0 || slot >= SkillSpec.slots(d.rank)) return;
        if (shape < 0 || shape >= Shape.values().length || el < 0 || el >= Element.values().length) return;
        if (Shape.values()[shape].minRank.ordinal() > d.rank.ordinal()) return;
        if (Element.values()[el].minRank.ordinal() > d.rank.ordinal()) return;
        List<Integer> mods = new ArrayList<>();
        for (int k = 3; k <= 5; k++) {
            int m = a[k];
            if (m < 0 || m >= SkillMod.values().length || mods.contains(m)) continue;
            if (SkillMod.values()[m].minRank.ordinal() > d.rank.ordinal()) continue;
            if (mods.size() >= SkillSpec.maxMods(d.rank)) break;
            mods.add(m);
        }
        SkillSpec sp = new SkillSpec(shape, el);
        for (int i = 0; i < mods.size(); i++) sp.mods[i] = mods.get(i);
        d.skills[slot] = sp;
    }

    private static void giveStarter(ServerPlayerEntity p, RpgData d) {
        String weapon;
        SkillSpec sk;
        switch (d.rpgClass) {
            case WARRIOR:
                weapon = "espada_longa";
                sk = new SkillSpec(Shape.MELEE.ordinal(), Element.PHYSICAL.ordinal());
                sk.mods[0] = SkillMod.KNOCKBACK.ordinal();
                break;
            case MAGE:
                weapon = "cajado_arcano";
                sk = new SkillSpec(Shape.PROJECTILE.ordinal(), Element.FIRE.ordinal());
                break;
            case ARCHER:
                weapon = "arco_curto";
                sk = new SkillSpec(Shape.PROJECTILE.ordinal(), Element.PHYSICAL.ordinal());
                break;
            default:
                weapon = "adaga_sombria";
                sk = new SkillSpec(Shape.MELEE.ordinal(), Element.PHYSICAL.ordinal());
                sk.mods[0] = SkillMod.DASH.ordinal();
                break;
        }
        give(p, new ItemStack(ModItems.get(weapon)));
        if (d.rpgClass == RpgClass.ARCHER) give(p, new ItemStack(Items.ARROW, 64));
        d.skills[0] = sk;
        GearUtil.Total g = GearUtil.of(p, d.rank);
        d.mana = SkillMath.maxMana(d.rpgClass, d.level, d.stats[3] + g.stats[3]);
        msg(p, "Classe escolhida! Skill inicial no slot 1 (tecla Z). Crie outras com a tecla J.", TextFormatting.GREEN);
    }

    private static void give(ServerPlayerEntity p, ItemStack s) {
        if (!p.inventory.add(s)) p.drop(s, false);
    }

    private static boolean consumeStone(ServerPlayerEntity p) {
        for (ItemStack s : p.inventory.items) {
            if (s.getItem() == ModItems.RANK_STONE.get()) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static void addXp(ServerPlayerEntity p, int amount) {
        RpgData d = RpgData.get(p);
        if (d.rpgClass == RpgClass.NONE || d.level >= d.cap()) return;
        d.xp += amount;
        while (d.level < d.cap() && d.xp >= d.xpToNext()) {
            d.xp -= d.xpToNext();
            d.level++;
            d.points += RpgData.POINTS_PER_LEVEL;
            msg(p, "Level up! Nível " + d.level + " (+" + RpgData.POINTS_PER_LEVEL + " pontos)", TextFormatting.GOLD);
        }
        if (d.level >= d.cap()) {
            d.xp = 0;
            msg(p, "Level cap do Rank " + d.rank.name() + " atingido! Use uma Pedra de Ascensão (tecla K).",
                    TextFormatting.YELLOW);
        }
        d.save(p);
        refresh(p, d);
    }

    public static void refresh(ServerPlayerEntity p) { refresh(p, RpgData.get(p)); }

    /** Reaplica os atributos (stats + equipamento + classe) e sincroniza com o cliente. */
    public static void refresh(ServerPlayerEntity p, RpgData d) {
        RpgClass c = d.rpgClass;
        boolean has = c != RpgClass.NONE;
        GearUtil.Total g = GearUtil.of(p, d.rank);
        int str = d.stats[0] + g.stats[0];
        int vit = d.stats[1] + g.stats[1];
        int agi = d.stats[2] + g.stats[2];
        int intel = d.stats[3] + g.stats[3];
        double lv = d.level - 1;

        mod(p, Attributes.MAX_HEALTH, HP_ID, "rpg_hp", has ? vit * 1.0 + lv * c.hpPerLevel : 0, AttributeModifier.Operation.ADDITION);
        mod(p, Attributes.ATTACK_DAMAGE, DMG_ID, "rpg_dmg", has ? str * 0.5 + lv * c.dmgPerLevel : 0, AttributeModifier.Operation.ADDITION);
        mod(p, Attributes.MOVEMENT_SPEED, SPD_ID, "rpg_spd", has ? agi * 0.005 + lv * c.speedPerLevel : 0, AttributeModifier.Operation.MULTIPLY_BASE);
        mod(p, Attributes.ATTACK_SPEED, ASPD_ID, "rpg_aspd", has ? agi * 0.02 : 0, AttributeModifier.Operation.ADDITION);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());

        d.maxMana = has ? SkillMath.maxMana(c, d.level, intel) : 0f;
        if (d.mana > d.maxMana) d.mana = d.maxMana;
        d.save(p);
        sync(p, d);
    }

    public static void sync(ServerPlayerEntity p, RpgData d) {
        CompoundNBT t = d.toTag();
        long now = p.level.getGameTime();
        long[] cds = SkillCaster.cdFor(p);
        int[] cd = new int[6];
        for (int i = 0; i < 6; i++) cd[i] = (int) Math.max(0, cds[i] - now);
        t.putIntArray("cd", cd);
        ModNetwork.CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncPacket(t));
    }

    private static void mod(PlayerEntity p, Attribute attr, UUID id, String name, double amount, AttributeModifier.Operation op) {
        ModifiableAttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        inst.removeModifier(id);
        if (amount != 0) inst.addPermanentModifier(new AttributeModifier(id, name, amount, op));
    }
}
