package com.rpgclasses.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.rpgclasses.data.*;
import com.rpgclasses.logic.GearUtil;
import com.rpgclasses.net.ActionPacket;
import com.rpgclasses.net.ModNetwork;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

import java.util.ArrayList;
import java.util.List;

public class RpgScreen extends Screen {
    private final List<Button> plus = new ArrayList<>();
    private Button rankBtn;
    private boolean built;

    public RpgScreen() { super(new StringTextComponent("Classe & Atributos")); }

    @Override
    protected void init() {
        plus.clear();
        rankBtn = null;
        RpgData d = ClientData.data;
        built = d.rpgClass != RpgClass.NONE;
        int cx = width / 2, top = Math.max(8, height / 2 - 100);
        if (!built) {
            int y = top + 34;
            for (RpgClass c : RpgClass.values()) {
                if (c == RpgClass.NONE) continue;
                final int idx = c.ordinal();
                addButton(new Button(cx - 150, y, 300, 20, new StringTextComponent(c.displayName + " - " + c.description),
                        b -> send(0, new int[]{idx})));
                y += 26;
            }
        } else {
            for (int i = 0; i < 4; i++) {
                final int idx = i;
                Button pb = new Button(cx + 100, top + 56 + i * 22, 20, 20, new StringTextComponent("+"),
                        b -> send(1, new int[]{idx}));
                plus.add(pb);
                addButton(pb);
            }
            rankBtn = addButton(new Button(cx - 100, top + 160, 200, 20,
                    new StringTextComponent("Subir de Rank (Pedra de Ascensão)"), b -> send(2, new int[0])));
            addButton(new Button(cx - 100, top + 184, 200, 20, new StringTextComponent("Editar Skills (J)"),
                    b -> minecraft.setScreen(new SkillScreen())));
        }
    }

    private void send(int action, int[] args) { ModNetwork.CH.sendToServer(new ActionPacket(action, args)); }

    @Override
    public void tick() {
        RpgData d = ClientData.data;
        if ((d.rpgClass != RpgClass.NONE) != built) {
            init(minecraft, width, height);
            return;
        }
        for (Button b : plus) b.active = d.points > 0;
        if (rankBtn != null) rankBtn.active = d.rank.next() != null && d.level >= d.cap();
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        renderBackground(ms);
        RpgData d = ClientData.data;
        int cx = width / 2, top = Math.max(8, height / 2 - 100);
        drawCenteredString(ms, font, title.getString(), cx, top, 0xFFFFFF);
        if (d.rpgClass == RpgClass.NONE) {
            drawCenteredString(ms, font, "Escolha sua classe (permanente)", cx, top + 16, 0xFFD700);
        } else {
            GearUtil.Total g = GearUtil.of(minecraft.player);
            drawCenteredString(ms, font, d.rpgClass.displayName + "  |  Rank " + d.rank.name(), cx, top + 14, 0xFFD700);
            String xp = d.level >= d.cap() ? "MAX" : d.xp + "/" + d.xpToNext();
            drawCenteredString(ms, font, "Nível " + d.level + "/" + d.cap() + "   XP " + xp, cx, top + 28, 0xFFFFFF);
            drawCenteredString(ms, font, "Pontos: " + d.points + "   Slots de skill: " + SkillSpec.slots(d.rank)
                    + "   Mods/skill: " + SkillSpec.maxMods(d.rank), cx, top + 42, 0x55FF55);
            for (int i = 0; i < 4; i++) {
                String bonus = g.stats[i] > 0 ? " §a+" + g.stats[i] + " (equip.)" : "";
                drawString(ms, font, RpgData.STAT_NAMES[i] + ": " + d.stats[i] + bonus + " §7(" + RpgData.STAT_HINTS[i] + ")",
                        cx - 130, top + 62 + i * 22, 0xFFFFFF);
            }
            if (g.skillPower > 0) drawCenteredString(ms, font, "Poder de skills (equip.): +" + Math.round(g.skillPower * 100) + "%",
                    cx, top + 148, 0x55FFFF);
            Rank next = d.rank.next();
            drawCenteredString(ms, font, next == null ? "Rank máximo" : "Próximo rank: " + next.name() + " (cap " + next.levelCap + ")",
                    cx, top + 208, 0xAAAAAA);
        }
        super.render(ms, mx, my, pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
