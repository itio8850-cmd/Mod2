package com.rpgclasses.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.rpgclasses.data.*;
import com.rpgclasses.logic.GearUtil;
import com.rpgclasses.net.ActionPacket;
import com.rpgclasses.net.ModNetwork;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

import java.util.Arrays;
import java.util.function.IntPredicate;

/** Criador de skills: forma + elemento + modificadores livres. */
public class SkillScreen extends Screen {
    private int slot = 0, shape = 0, element = 1;
    private final int[] mods = {-1, -1, -1};
    private Button shapeBtn, elemBtn;
    private final Button[] modBtns = new Button[3];

    public SkillScreen() {
        super(new StringTextComponent("Criador de Skills"));
        load();
    }

    private RpgData d() { return ClientData.data; }
    private int slots() { return SkillSpec.slots(d().rank); }

    private void load() {
        if (slot >= slots()) slot = 0;
        SkillSpec s = d().skills[slot];
        if (s != null) {
            shape = s.shape;
            element = s.element;
            for (int i = 0; i < 3; i++) mods[i] = s.mods[i];
        } else {
            shape = 0;
            element = 1;
            Arrays.fill(mods, -1);
        }
    }

    private int cycle(int cur, int dir, int min, int max, IntPredicate ok) {
        int n = max - min + 1;
        for (int i = 1; i <= n; i++) {
            int c = ((cur - min + dir * i) % n + n) % n + min;
            if (ok.test(c)) return c;
        }
        return cur;
    }

    @Override
    protected void init() {
        int cx = width / 2, top = Math.max(6, height / 2 - 112);
        addButton(new Button(cx - 110, top + 12, 20, 20, new StringTextComponent("<"), b -> {
            slot = (slot + slots() - 1) % slots();
            load();
            labels();
        }));
        addButton(new Button(cx + 90, top + 12, 20, 20, new StringTextComponent(">"), b -> {
            slot = (slot + 1) % slots();
            load();
            labels();
        }));
        shapeBtn = addButton(new Button(cx - 110, top + 36, 220, 20, new StringTextComponent(""), b -> {
            int r = d().rank.ordinal();
            shape = cycle(shape, 1, 0, Shape.values().length - 1, v -> Shape.values()[v].minRank.ordinal() <= r);
            labels();
        }));
        elemBtn = addButton(new Button(cx - 110, top + 58, 220, 20, new StringTextComponent(""), b -> {
            int r = d().rank.ordinal();
            element = cycle(element, 1, 0, Element.values().length - 1, v -> Element.values()[v].minRank.ordinal() <= r);
            labels();
        }));
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            modBtns[i] = addButton(new Button(cx - 110, top + 80 + i * 22, 220, 20, new StringTextComponent(""), b -> {
                int r = d().rank.ordinal();
                mods[idx] = cycle(mods[idx], 1, -1, SkillMod.values().length - 1, v -> {
                    if (v == -1) return true;
                    if (SkillMod.values()[v].minRank.ordinal() > r) return false;
                    for (int j = 0; j < 3; j++) if (j != idx && mods[j] == v) return false;
                    return true;
                });
                labels();
            }));
        }
        addButton(new Button(cx - 110, top + 208, 70, 20, new StringTextComponent("Salvar"), b -> {
            ModNetwork.CH.sendToServer(new ActionPacket(4, new int[]{slot, shape, element, mods[0], mods[1], mods[2]}));
        }));
        addButton(new Button(cx - 35, top + 208, 70, 20, new StringTextComponent("Apagar"), b -> {
            ModNetwork.CH.sendToServer(new ActionPacket(5, new int[]{slot}));
        }));
        addButton(new Button(cx + 40, top + 208, 70, 20, new StringTextComponent("Voltar"), b -> {
            minecraft.setScreen(new RpgScreen());
        }));
        labels();
    }

    private void labels() {
        if (shapeBtn == null) return;
        shapeBtn.setMessage(new StringTextComponent("Forma: " + Shape.values()[shape].display));
        elemBtn.setMessage(new StringTextComponent("Elemento: " + Element.values()[element].display));
        int max = SkillSpec.maxMods(d().rank);
        for (int i = 0; i < 3; i++) {
            if (i >= max) {
                modBtns[i].active = false;
                modBtns[i].setMessage(new StringTextComponent("Mod " + (i + 1) + ": (rank maior)"));
            } else {
                modBtns[i].active = true;
                modBtns[i].setMessage(new StringTextComponent("Mod " + (i + 1) + ": "
                        + (mods[i] < 0 ? "—" : SkillMod.values()[mods[i]].display)));
            }
        }
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        renderBackground(ms);
        int cx = width / 2, top = Math.max(6, height / 2 - 112);
        RpgData d = d();
        drawCenteredString(ms, font, "Slot " + (slot + 1) + "/" + slots() + "  (tecla "
                + Keys.SKILL[slot].getTranslatedKeyMessage().getString() + ")", cx, top + 4, 0xFFD700);

        SkillSpec cur = new SkillSpec(shape, element);
        for (int i = 0; i < 3; i++) cur.mods[i] = (i < SkillSpec.maxMods(d.rank)) ? mods[i] : -1;
        GearUtil.Total g = GearUtil.of(minecraft.player);
        float dmg = SkillMath.damage(d.rpgClass, d.level, cur, d.stats[0] + g.stats[0], d.stats[3] + g.stats[3], g.skillPower);
        int y = top + 148;
        drawCenteredString(ms, font, cur.name(), cx, y, 0x55FFFF);
        drawCenteredString(ms, font, "Mana: " + SkillMath.mana(d.rpgClass, cur) + "   Recarga: "
                + String.format("%.1f", SkillMath.cooldown(d.rpgClass, cur) / 20f) + "s   Dano: "
                + (dmg > 0 ? String.format("%.1f", dmg) : "—"), cx, y + 11, 0xFFFFFF);
        int ly = y + 23;
        for (int i = 0; i < 3; i++) {
            if (cur.mods[i] >= 0) {
                SkillMod m = SkillMod.values()[cur.mods[i]];
                drawCenteredString(ms, font, m.display + ": " + m.desc, cx, ly, 0xAAAAAA);
                ly += 10;
            }
        }
        super.render(ms, mx, my, pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
